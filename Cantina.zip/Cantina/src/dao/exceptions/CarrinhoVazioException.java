package dao.exceptions;

public class CarrinhoVazioException extends Exception {
    public CarrinhoVazioException(String message) {
        super(message);
    }
}