package dao.exceptions;

public class LoginJaExistenteException extends Exception {
    public LoginJaExistenteException(String message) {
        super(message);
    }
}