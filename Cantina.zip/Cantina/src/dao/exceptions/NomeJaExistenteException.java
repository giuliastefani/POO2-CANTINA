package dao.exceptions;

public class NomeJaExistenteException extends Exception {
    public NomeJaExistenteException(String message) {
        super(message);
    }
}
